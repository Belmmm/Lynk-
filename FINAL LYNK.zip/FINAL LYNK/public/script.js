// ===== GAME DATA =====
const GAMES = [
  { id:'puzzle',   name:'Puzzle Deslizante', icon:'🧩', cat:'Puzzle',    rating:4.8, desc:'3×3, 4×4, 5×5 — ordena las piezas', color:'#7c3aed', badge:'TOP'  },
  { id:'laoca',    name:'La Oca',            icon:'🪿', cat:'Mesa',      rating:4.7, desc:'Tablero clásico con todas las reglas', color:'#10b981', badge:'HOT'  },
  { id:'domino',   name:'Dominó',            icon:'🁣', cat:'Mesa',      rating:4.6, desc:'28 fichas — juega vs CPU',             color:'#f59e0b', badge:null   },
  { id:'parchis',  name:'Parchís',           icon:'🎲', cat:'Mesa',      rating:4.5, desc:'4 fichas — carreras y capturas',       color:'#ef4444', badge:'NUEVO'},
  { id:'memory',   name:'Memory',            icon:'🃏', cat:'Puzzle',    rating:4.4, desc:'Encuentra todas las parejas',          color:'#ec4899', badge:null   },
  { id:'tresraya', name:'Tres en Raya',      icon:'⭕', cat:'Mesa',      rating:4.3, desc:'vs CPU Normal o Difícil (minimax)',    color:'#22d3ee', badge:null   },
];

const GAME_NAMES = { puzzle:'Puzzle', laoca:'La Oca', domino:'Dominó', parchis:'Parchís', memory:'Memory', tresraya:'Tres en Raya' };

// ===== STATE =====
let currentUser  = null;
let activeGameId = null;

// ===== INIT =====
document.addEventListener('DOMContentLoaded', async () => {
  createParticles();
  renderGames();
  await tryAutoLogin();
  loadLeaderboard();
  listenGameMessages();
});

// ===== AUTO LOGIN =====
async function tryAutoLogin() {
  const token = localStorage.getItem('lynk_token');
  if (!token) return;
  try {
    const res = await apiFetch('/api/profile');
    if (res.ok) {
      const user = await res.json();
      currentUser = user;
      updateNavForUser(user);
    } else {
      localStorage.removeItem('lynk_token');
    }
  } catch { localStorage.removeItem('lynk_token'); }
}

// ===== API HELPER =====
async function apiFetch(url, opts = {}) {
  const token = localStorage.getItem('lynk_token');
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  return fetch(url, { ...opts, headers });
}

// ===== PARTICLES =====
function createParticles() {
  const c = document.getElementById('particles');
  if (!c) return;
  for (let i = 0; i < 30; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.cssText = `left:${Math.random()*100}%;animation-duration:${8+Math.random()*12}s;animation-delay:${Math.random()*10}s;width:${1+Math.random()*3}px;height:${1+Math.random()*3}px`;
    c.appendChild(p);
  }
}

// ===== RENDER GAMES =====
function renderGames() {
  const grid = document.getElementById('games-grid');
  grid.innerHTML = '';
  GAMES.forEach(g => {
    const card = document.createElement('div');
    card.className = 'game-card';
    card.onclick = () => launchGame(g);
    card.innerHTML = `
      ${g.badge ? `<div class="game-badge">${g.badge}</div>` : ''}
      <div class="game-thumb" style="background:linear-gradient(135deg,${g.color}22,${g.color}55)">
        <span style="font-size:4.5rem">${g.icon}</span>
      </div>
      <div class="game-info">
        <div class="game-name">${g.name}</div>
        <div class="game-meta">
          <span class="game-cat">${g.cat}</span>
          <span class="game-rating">★ ${g.rating}</span>
        </div>
        <div class="game-plays">${g.desc}</div>
      </div>`;
    grid.appendChild(card);
  });
}

// ===== LEADERBOARD =====
async function loadLeaderboard() {
  try {
    const res  = await fetch('/api/leaderboard');
    const data = await res.json();
    const tbody = document.getElementById('leaderboard-body');
    if (!tbody) return;
    tbody.innerHTML = '';
    const medals = ['🥇','🥈','🥉'];
    data.forEach((u, i) => {
      const winRate = u.stats?.gamesPlayed ? Math.round(u.stats.gamesWon / u.stats.gamesPlayed * 100) : 0;
      const tr = document.createElement('div');
      tr.className = 'rank-row' + (i < 3 ? [' gold',' silver',' bronze'][i] : '');
      tr.innerHTML = `
        <span class="rank-pos">${medals[i] || i+1}</span>
        <span class="rank-player">
          <div class="rank-avatar" style="background:${u.avatarColor}">${u.avatar}</div>
          ${u.username}
        </span>
        <span class="rank-pts">${u.xp?.toLocaleString()}</span>
        <span class="rank-lvl">Lvl ${u.level}</span>
        <span class="rank-wr">${winRate}%</span>`;
      tbody.appendChild(tr);
    });
  } catch {}
}

// ===== GAME LAUNCHER =====
function launchGame(game) {
  activeGameId = game.id;
  document.getElementById('game-title').textContent = `${game.icon} ${game.name}`;
  document.getElementById('game-iframe').src = `games/${game.id}.html`;
  document.getElementById('game-overlay').classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeGame() {
  document.getElementById('game-overlay').classList.remove('active');
  document.getElementById('game-iframe').src = '';
  document.body.style.overflow = '';
  activeGameId = null;
}

// ===== LISTEN GAME RESULTS (postMessage from iframes) =====
function listenGameMessages() {
  window.addEventListener('message', async (e) => {
    if (!e.data || e.data.type !== 'GAME_RESULT') return;
    if (!currentUser) return;
    const { game, result, score, duration } = e.data;
    try {
      const res = await apiFetch('/api/games/save', {
        method: 'POST',
        body: JSON.stringify({ game: game || activeGameId, result, score, duration })
      });
      const data = await res.json();
      if (data.success) {
        // Update local user xp/level
        currentUser.xp    = data.newXp;
        currentUser.level = data.newLevel;
        updateNavForUser(currentUser);
        const msgs = { win:'¡Ganaste! 🎉', loss:'Buena partida', draw:'¡Empate!' };
        showToast(`${msgs[result] || 'Partida guardada'} +${data.xpGained} XP`, result === 'win' ? 'success' : 'info');
        if (data.streak >= 3) showToast(`🔥 Racha de ${data.streak}! +15 XP bonus`, 'success');
      }
    } catch {}
  });
}

// ===== NAVBAR =====
window.addEventListener('scroll', () => {
  document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 50);
});

function toggleMenu() {
  const nav = document.getElementById('mobile-nav');
  nav.classList.toggle('open');
}

// ===== MODAL CONTROL =====
function openModal(tab = 'login') {
  document.getElementById('modal-overlay').classList.add('active');
  document.body.style.overflow = 'hidden';
  switchTab(tab);
  clearErrors();
}
function closeModal() {
  document.getElementById('modal-overlay').classList.remove('active');
  document.body.style.overflow = '';
  clearErrors();
}
function closeModalOutside(e) {
  if (e.target === document.getElementById('modal-overlay')) closeModal();
}
function switchTab(tab) {
  ['login','register'].forEach(t => {
    document.getElementById(`tab-${t}`).classList.toggle('active', t === tab);
    document.getElementById(`form-${t}`).classList.toggle('hidden', t !== tab);
  });
  clearErrors();
}
function clearErrors() {
  document.getElementById('login-error').textContent  = '';
  document.getElementById('reg-error').textContent    = '';
}

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeModal(); closeGame(); }
  if (e.key === 'Enter') {
    const overlay = document.getElementById('modal-overlay');
    if (!overlay.classList.contains('active')) return;
    const loginVisible = !document.getElementById('form-login').classList.contains('hidden');
    if (loginVisible) handleLogin(); else handleRegister();
  }
});

function fillDemo() {
  document.getElementById('login-user').value = 'player1';
  document.getElementById('login-pass').value = '1234';
}

// ===== LOGIN =====
async function handleLogin() {
  const username = document.getElementById('login-user').value.trim();
  const password = document.getElementById('login-pass').value;
  const errEl    = document.getElementById('login-error');
  const btn      = document.getElementById('login-submit');
  if (!username || !password) { errEl.textContent = 'Completa todos los campos'; return; }

  btn.disabled = true; btn.textContent = 'Entrando...';
  try {
    const res  = await fetch('/api/auth/login', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ username, password }) });
    const data = await res.json();
    if (data.success) {
      localStorage.setItem('lynk_token', data.token);
      currentUser = data.user;
      closeModal();
      updateNavForUser(data.user);
      showToast(`¡Bienvenido, ${data.user.username}! 👋`, 'success');
    } else {
      errEl.textContent = data.error || 'Error al iniciar sesion';
    }
  } catch { errEl.textContent = 'Error de conexion'; }
  finally { btn.disabled = false; btn.textContent = 'Entrar al juego'; }
}

// ===== REGISTER =====
async function handleRegister() {
  const username = document.getElementById('reg-user').value.trim();
  const email    = document.getElementById('reg-email').value.trim();
  const pass     = document.getElementById('reg-pass').value;
  const pass2    = document.getElementById('reg-pass2').value;
  const errEl    = document.getElementById('reg-error');
  const btn      = document.getElementById('reg-submit');
  if (!username || !email || !pass || !pass2) { errEl.textContent = 'Completa todos los campos'; return; }
  if (pass !== pass2) { errEl.textContent = 'Las contraseñas no coinciden'; return; }

  btn.disabled = true; btn.textContent = 'Creando...';
  try {
    const res  = await fetch('/api/auth/register', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ username, email, password: pass }) });
    const data = await res.json();
    if (data.success) {
      localStorage.setItem('lynk_token', data.token);
      currentUser = data.user;
      closeModal();
      updateNavForUser(data.user);
      showToast(`¡Bienvenido a LYNK, ${data.user.username}! 🎮`, 'success');
    } else {
      errEl.textContent = data.error || 'Error al registrarse';
    }
  } catch { errEl.textContent = 'Error de conexion'; }
  finally { btn.disabled = false; btn.textContent = 'Crear Cuenta'; }
}

// ===== NAV USER =====
function updateNavForUser(user) {
  const actions = document.querySelector('.nav-actions');
  const xpForNext = (Math.floor(user.xp / 500) + 1) * 500;
  const pct = Math.round(((user.xp % 500) / 500) * 100);
  actions.innerHTML = `
    <div class="user-chip" onclick="goToProfile()">
      <div class="chip-avatar" style="background:${user.avatarColor}">${user.avatar}</div>
      <div class="chip-info">
        <span class="chip-name">${user.username}</span>
        <div class="chip-xp-bar"><div class="chip-xp-fill" style="width:${pct}%"></div></div>
        <span class="chip-level">Lvl ${user.level}</span>
      </div>
    </div>
    ${user.role === 'admin' ? `<a href="/admin.html" class="btn-admin">Admin</a>` : ''}
    <button class="btn-logout" onclick="logout()">✕</button>`;
}

function goToProfile() { window.location.href = '/profile.html'; }

function logout() {
  localStorage.removeItem('lynk_token');
  currentUser = null;
  document.querySelector('.nav-actions').innerHTML = `
    <button class="btn-login" onclick="openModal()">Iniciar Sesion</button>
    <button class="btn-register" onclick="openModal('register')">Registrarse</button>`;
  showToast('Sesion cerrada', 'info');
}

// ===== TOAST =====
function showToast(msg, type = 'success') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = `toast ${type}`;
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.add('hidden'), 3800);
}

// ===== SCROLL SPY =====
document.querySelectorAll('.nav-links a').forEach(a => {
  a.addEventListener('click', () => document.getElementById('mobile-nav')?.classList.remove('open'));
});
