const express = require('express');
const path    = require('path');
const fs      = require('fs');
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');

const app    = express();
const PORT   = 3000;
const SECRET = process.env.JWT_SECRET || 'lynk_secret_xk2026';
const DB     = path.join(__dirname, 'data', 'db.json');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ─── DB helpers ────────────────────────────────────────────────────────────
function readDB() {
  try { return JSON.parse(fs.readFileSync(DB, 'utf8')); }
  catch { return { users: [] }; }
}
function writeDB(data) {
  fs.mkdirSync(path.dirname(DB), { recursive: true });
  fs.writeFileSync(DB, JSON.stringify(data, null, 2));
}
function genId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
function getLevel(xp) { return Math.max(1, Math.floor(xp / 500) + 1); }
function repTitle(r) {
  if (r < 50)   return 'Novato';
  if (r < 150)  return 'Aficionado';
  if (r < 350)  return 'Regular';
  if (r < 600)  return 'Competitivo';
  if (r < 1000) return 'Experto';
  return 'Leyenda';
}
const AVATAR_COLORS = ['#7c3aed','#10b981','#f59e0b','#ef4444','#3b82f6','#ec4899','#22d3ee','#8b5cf6'];

// ─── Seed ─────────────────────────────────────────────────────────────────
(function seed() {
  const db = readDB();
  if (db.users.length) return;
  db.users = [
    {
      id:'admin1', username:'admin', email:'admin@lynk.com',
      password: bcrypt.hashSync('admin123', 10),
      role:'admin', avatar:'A', avatarColor:'#7c3aed',
      bio:'Administrador de LYNK Games',
      reputation:850, xp:22000, level:45, streak:5, banned:false,
      createdAt: new Date(Date.now()-30*86400000).toISOString(),
      lastLogin: new Date().toISOString(),
      stats:{ gamesPlayed:120, gamesWon:89, gamesLost:25, gamesDraw:6, totalPoints:22000 },
      gameHistory:[
        {id:'g1',game:'domino',result:'win',score:340,duration:600,xpGained:65,date:new Date(Date.now()-86400000).toISOString()},
        {id:'g2',game:'puzzle',result:'win',score:180,duration:210,xpGained:50,date:new Date(Date.now()-172800000).toISOString()},
        {id:'g3',game:'laoca', result:'loss',score:0,  duration:480,xpGained:10,date:new Date(Date.now()-259200000).toISOString()},
      ]
    },
    {
      id:'user1', username:'player1', email:'player1@lynk.com',
      password: bcrypt.hashSync('1234', 10),
      role:'user', avatar:'P', avatarColor:'#10b981',
      bio:'Me encantan los juegos de mesa',
      reputation:210, xp:4800, level:10, streak:2, banned:false,
      createdAt: new Date(Date.now()-15*86400000).toISOString(),
      lastLogin: new Date().toISOString(),
      stats:{ gamesPlayed:47, gamesWon:28, gamesLost:15, gamesDraw:4, totalPoints:4800 },
      gameHistory:[
        {id:'g4',game:'tresraya',result:'win',  score:50, duration:60, xpGained:50,date:new Date(Date.now()-3600000).toISOString()},
        {id:'g5',game:'memory',  result:'win',  score:120,duration:180,xpGained:50,date:new Date(Date.now()-86400000).toISOString()},
        {id:'g6',game:'puzzle',  result:'loss', score:40, duration:300,xpGained:10,date:new Date(Date.now()-172800000).toISOString()},
        {id:'g7',game:'laoca',   result:'draw', score:30, duration:900,xpGained:20,date:new Date(Date.now()-259200000).toISOString()},
      ]
    },
    {
      id:'user2', username:'XDragonZ', email:'xdragon@lynk.com',
      password: bcrypt.hashSync('dragon123', 10),
      role:'user', avatar:'X', avatarColor:'#f59e0b',
      bio:'', reputation:980, xp:49000, level:99, streak:8, banned:false,
      createdAt: new Date(Date.now()-90*86400000).toISOString(),
      lastLogin: new Date(Date.now()-3600000).toISOString(),
      stats:{ gamesPlayed:320, gamesWon:240, gamesLost:70, gamesDraw:10, totalPoints:49000 },
      gameHistory:[]
    },
  ];
  writeDB(db);
  console.log('  DB inicializada con datos de prueba');
})();

// ─── Auth middleware ────────────────────────────────────────────────────────
function auth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No autorizado' });
  try { req.user = jwt.verify(token, SECRET); next(); }
  catch { res.status(401).json({ error: 'Token invalido o expirado' }); }
}
function adminAuth(req, res, next) {
  auth(req, res, () => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Acceso denegado' });
    next();
  });
}
function safe(u) { const { password: _, ...rest } = u; return rest; }

// ─── Auth routes ───────────────────────────────────────────────────────────
app.post('/api/auth/register', (req, res) => {
  const { username, email, password } = req.body;
  if (!username || !email || !password)
    return res.status(400).json({ error: 'Todos los campos son requeridos' });
  if (username.length < 3)
    return res.status(400).json({ error: 'El usuario debe tener al menos 3 caracteres' });
  if (password.length < 6)
    return res.status(400).json({ error: 'La contraseña debe tener al menos 6 caracteres' });
  if (!/\S+@\S+\.\S+/.test(email))
    return res.status(400).json({ error: 'Email invalido' });

  const db = readDB();
  if (db.users.find(u => u.username.toLowerCase() === username.toLowerCase()))
    return res.status(400).json({ error: 'El usuario ya existe' });
  if (db.users.find(u => u.email.toLowerCase() === email.toLowerCase()))
    return res.status(400).json({ error: 'El email ya esta registrado' });

  const user = {
    id: genId(), username, email,
    password: bcrypt.hashSync(password, 10),
    role: 'user',
    avatar: username[0].toUpperCase(),
    avatarColor: AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)],
    bio: '', reputation: 0, xp: 0, level: 1, streak: 0, banned: false,
    createdAt: new Date().toISOString(),
    lastLogin: new Date().toISOString(),
    stats: { gamesPlayed:0, gamesWon:0, gamesLost:0, gamesDraw:0, totalPoints:0 },
    gameHistory: []
  };
  db.users.push(user);
  writeDB(db);
  const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, SECRET, { expiresIn: '7d' });
  res.json({ success: true, token, user: safe(user) });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const db = readDB();
  const user = db.users.find(u => u.username.toLowerCase() === username?.toLowerCase());
  if (!user || !bcrypt.compareSync(password || '', user.password))
    return res.status(401).json({ error: 'Usuario o contraseña incorrectos' });
  if (user.banned) return res.status(403).json({ error: 'Cuenta suspendida por el administrador' });
  user.lastLogin = new Date().toISOString();
  writeDB(db);
  const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, SECRET, { expiresIn: '7d' });
  res.json({ success: true, token, user: safe(user) });
});

// ─── Profile routes ─────────────────────────────────────────────────────────
app.get('/api/profile', auth, (req, res) => {
  const db = readDB();
  const user = db.users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'Usuario no encontrado' });
  res.json(safe(user));
});

app.put('/api/profile', auth, (req, res) => {
  const { avatarColor, bio } = req.body;
  const db = readDB();
  const user = db.users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'No encontrado' });
  if (avatarColor && AVATAR_COLORS.includes(avatarColor)) user.avatarColor = avatarColor;
  if (bio !== undefined) user.bio = String(bio).slice(0, 200);
  writeDB(db);
  res.json(safe(user));
});

// ─── Games routes ─────────────────────────────────────────────────────────
app.post('/api/games/save', auth, (req, res) => {
  const { game, result, score, duration } = req.body;
  if (!game || !['win','loss','draw'].includes(result))
    return res.status(400).json({ error: 'Datos invalidos' });

  const db   = readDB();
  const user = db.users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'No encontrado' });

  let xp  = result === 'win' ? 50 : result === 'draw' ? 20 : 10;
  let rep = result === 'win' ? 10 : result === 'draw' ? 4  : 1;
  rep += 3; // bonus por participar

  if (result === 'win') {
    user.streak = (user.streak || 0) + 1;
    if (user.streak >= 3) { xp += 15; rep += 5; } // racha
  } else {
    user.streak = 0;
  }

  user.xp         = (user.xp || 0) + xp;
  user.reputation = (user.reputation || 0) + rep;
  user.level      = getLevel(user.xp);
  user.stats.gamesPlayed++;
  if (result === 'win')  user.stats.gamesWon++;
  else if (result === 'loss') user.stats.gamesLost++;
  else user.stats.gamesDraw++;
  user.stats.totalPoints = user.xp;

  const entry = { id: genId(), game, result, score: score || 0, duration: duration || 0, xpGained: xp, date: new Date().toISOString() };
  user.gameHistory.unshift(entry);
  if (user.gameHistory.length > 100) user.gameHistory = user.gameHistory.slice(0, 100);
  writeDB(db);

  res.json({ success: true, xpGained: xp, repGained: rep, newLevel: user.level, newXp: user.xp, streak: user.streak });
});

// ─── Leaderboard ──────────────────────────────────────────────────────────
app.get('/api/leaderboard', (req, res) => {
  const db = readDB();
  const top = db.users
    .filter(u => !u.banned)
    .sort((a, b) => (b.xp || 0) - (a.xp || 0))
    .slice(0, 20)
    .map(({ id, username, avatar, avatarColor, xp, level, reputation, stats }) =>
      ({ id, username, avatar, avatarColor, xp, level, reputation, stats })
    );
  res.json(top);
});

// ─── Admin routes ──────────────────────────────────────────────────────────
app.get('/api/admin/users', adminAuth, (req, res) => {
  const db = readDB();
  res.json(db.users.map(safe));
});

app.put('/api/admin/users/:id', adminAuth, (req, res) => {
  const db = readDB();
  const user = db.users.find(u => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: 'No encontrado' });
  const { banned, role, reputation, xp } = req.body;
  if (banned    !== undefined) user.banned = Boolean(banned);
  if (role && ['user','admin'].includes(role)) user.role = role;
  if (reputation !== undefined) user.reputation = Math.max(0, Number(reputation));
  if (xp         !== undefined) { user.xp = Math.max(0, Number(xp)); user.level = getLevel(user.xp); }
  writeDB(db);
  res.json(safe(user));
});

app.delete('/api/admin/users/:id', adminAuth, (req, res) => {
  const db = readDB();
  const idx = db.users.findIndex(u => u.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'No encontrado' });
  if (db.users[idx].role === 'admin') return res.status(400).json({ error: 'No puedes eliminar un admin' });
  db.users.splice(idx, 1);
  writeDB(db);
  res.json({ success: true });
});

app.get('/api/admin/stats', adminAuth, (req, res) => {
  const db = readDB();
  const users = db.users;
  const byGame = {};
  users.forEach(u => (u.gameHistory || []).forEach(g => { byGame[g.game] = (byGame[g.game] || 0) + 1; }));
  const newToday = users.filter(u => new Date(u.createdAt) > new Date(Date.now() - 86400000)).length;
  res.json({
    totalUsers:   users.length,
    activeUsers:  users.filter(u => !u.banned).length,
    bannedUsers:  users.filter(u => u.banned).length,
    newToday,
    totalGames:   users.reduce((s, u) => s + (u.stats?.gamesPlayed || 0), 0),
    totalWins:    users.reduce((s, u) => s + (u.stats?.gamesWon || 0), 0),
    byGame,
  });
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, () => console.log(`\n  LYNK Games → http://localhost:${PORT}\n  Admin: usuario=admin / pass=admin123\n  Demo:  usuario=player1 / pass=1234\n`));
